tinyMCE.addI18n('nb.uploadimage_dlg', {
  title: 'Sett inn bilde',
  header: "Sett inn bilde",
  input:  "Velg et bilde",
  insert: "Sett inn",
  cancel: "Avbryt"
});
