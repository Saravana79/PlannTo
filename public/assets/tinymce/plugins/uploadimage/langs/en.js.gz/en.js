tinyMCE.addI18n('en.uploadimage', {
  desc: 'Insert an image from your computer'
});
